package Access_modifiers_public;

public class Class_1 {
    public static void main(String[] args) {
        Class_1 S = new Class_1();
        System.out.println(S.rollno);
        S.printrollno();
        S.abc();
    }
    public  int rollno = 101;
    public Class_1() {
        rollno = 102;
    }
        public void printrollno(){
            System.out.println(rollno);

        }

        private void abc(){
        printrollno();

        }
    }





