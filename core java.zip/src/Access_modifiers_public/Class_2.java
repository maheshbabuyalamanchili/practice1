package Access_modifiers_public;

public class Class_2 {
    public static void main(String[] args) {
        Class_1 S = new Class_1();
        System.out.println(S.rollno);
        S.printrollno();
    }

}
