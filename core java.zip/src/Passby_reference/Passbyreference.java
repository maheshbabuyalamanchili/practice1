package Passby_reference;

public class Passbyreference {
int a =20;



    public static void main(String[] args) {
      Passbyreference d1  =  new Passbyreference();
        System.out.println(d1.a);
        add(d1);
    }


    static void add(Passbyreference d2 ){
        System.out.println(d2.a);}




    }

