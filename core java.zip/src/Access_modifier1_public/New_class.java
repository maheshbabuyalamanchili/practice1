package Access_modifier1_public;

import Access_modifiers_public.Class_1;

public class New_class {
    public static void main(String[] args) {
            Class_1 S = new Class_1();
            System.out.println(S.rollno);
            S.printrollno();

    }

}
