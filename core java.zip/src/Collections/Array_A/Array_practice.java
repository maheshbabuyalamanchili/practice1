package Collections.Array_A;

import java.util.*;

public class Array_practice {
    public static void main(String[] args) {
        //size-no.of elements present in list
        //capacity-Array capacity
         ArrayList a1= new ArrayList();
        a1.add("11");
        a1.add("22");
        a1.add(0,"33"); //passsing index
        a1.add("44");
        a1.add("55");
        a1.add("66");
        a1.add("77");
        a1.add("88");
        a1.add("99");
        a1.add("1010");

        System.out.println(a1);

        System.out.println("size."+ a1.size());

    }
}
