package Interface;

public interface Laptop {
    public void copy();

    public void cut();


    public void paste();

    default void security() {
        System.out.println(" laptop security code");
    }

    static void audio(){
        System.out.println("laptop audio code");
    }


    }


