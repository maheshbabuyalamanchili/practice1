package Interface;

public class User {
    public static void main(String[] args) {
          Lenovo lnv = new Lenovo();
            lnv.copy();
            lnv.cut();
            lnv.paste();
            lnv.camera();
            lnv.security();
            Laptop.audio();

            Hp hp = new Hp();
                hp.copy();
                hp.cut();
                hp.paste();
                hp.ptinter();


                Apple ap =new Apple();
                ap.copy();
                ap.cut();
                ap.paste();
                ap.security();


                }
            }
