package Interface;

public class Lenovo implements Laptop {


    public void copy() {
        System.out.println("lenovo copy code");

    }


    public void cut() {
        System.out.println("lenovo cut code");

    }


    public void paste() {
        System.out.println("lenovo paste code");
    }

    public void camera(){
        System.out.println("lenova camera code");
    }

    public void security(){
        System.out.println("lenovo security code");
    }


}
