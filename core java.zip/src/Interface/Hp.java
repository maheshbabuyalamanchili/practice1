package Interface;

public class Hp implements Laptop {

    public void copy() {
        System.out.println("Hp copy code");
    }


    public void cut() {
        System.out.println("Hp cut code");
    }


    public void paste() {
        System.out.println("Hp paste code");
    }

    public void ptinter(){
        System.out.println("Hp printer code");
    }

    }


