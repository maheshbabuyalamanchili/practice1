package Arrays;

public class Single_dimensional_array {
    public static void main(String[] args) {
        ///INT
     // 1
        int [] a = new int[5];

        a[0]=2;
        a[1]=4;
        a[2]=6;
        a[3]=8;
        a[4]=10;
        System.out.println(a[0]);
        System.out.println(a[1]);
        System.out.println(a[2]);
        System.out.println(a[3]);
        System.out.println(a[4]);

        for (int i= 0;i<a.length;i++) {
            System.out.println(a[i]);

        }
          // 2
            int [] b =new int[] {2,4,6,8,10};
            System.out.println(b[0]);
            System.out.println(b[1]);

            for (int i= 0;i<b.length;i++){
                System.out.println(b[i]);
            }

         // 3
        int [] c = {2,4,6,8,10};
        System.out.println(c[0]);
        System.out.println(c[1]);

        for (int i= 0;i<c.length;i++){
            System.out.println(c[i]);
        }

        ////////STRING
        String[] d = new String[5];
        d[0] = "abc";
        d[1] = "def";
        d[2] = "ghi";
        d[3] = "jkl";
        d[4] = "mno";
        System.out.println(d[0]);
        System.out.println(d[1]);
        System.out.println(d[2]);
        System.out.println(d[3]);
        System.out.println(d[4]);

        for (int i = 0; i < d.length; i++) {
            System.out.println(d[i]);

        }

        ////CHAR
        char[]e=new char[3];
        e [0] ='a';
        e [1] ='b';
        e [2] ='c';
        System.out.println(e[0]);
        System.out.println(e[1]);
        System.out.println(e[2]);

        for ( int i=0; i<e.length;i++){
            System.out.println(e[i]);
        }


    }
}