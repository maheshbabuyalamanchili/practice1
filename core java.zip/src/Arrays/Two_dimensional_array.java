package Arrays;

public class Two_dimensional_array {
}
