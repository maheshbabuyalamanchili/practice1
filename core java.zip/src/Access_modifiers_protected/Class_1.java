package Access_modifiers_protected;

public class Class_1 {
    public static void main(String[] args) {
        Class_1 C = new Class_1();
        System.out.println(C.rollno);
        C.printrollno();
    }

    protected int rollno = 101;

    protected Class_1(){
        rollno = 104;
    }

    protected void printrollno(){
        System.out.println(rollno);
    }

}
