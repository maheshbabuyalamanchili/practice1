package Access_modifiers_protected;

public class Class_2 {
    public static void main(String[] args) {
        Class_1 C = new Class_1();
        System.out.println(C.rollno);
        C.printrollno();
    }
}
