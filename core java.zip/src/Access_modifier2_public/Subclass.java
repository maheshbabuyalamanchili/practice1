package Access_modifier2_public;

import Access_modifiers_public.Class_1;

public class Subclass extends Class_1 {
    public static void main(String[] args) {
        Subclass S1 = new Subclass();
        System.out.println(S1.rollno);
        S1.printrollno();

    }
    public void test() {
        System.out.println( rollno);
        printrollno();


    }

}