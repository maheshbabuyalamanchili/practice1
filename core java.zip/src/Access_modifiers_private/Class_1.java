package Access_modifiers_private;

public class Class_1 {

    public static void main(String[] args) {
       Class_1 C = new Class_1();
        System.out.println(C.rollno);
        C.printrollno();
        C.abc();

    }

    private int rollno = 101;

    private Class_1(){
        rollno=103;
    }
       private void printrollno(){
           System.out.println(rollno);

       }

       public void abc(){
           System.out.println(rollno);
           printrollno();
       }

}
