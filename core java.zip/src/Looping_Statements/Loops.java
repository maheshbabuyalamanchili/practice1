package Looping_Statements;

public class Loops {
    public static void main(String[] args) {
//        int a = 10;

//        while(a<=15) {
//            System.out.println(a);
//            a++;
//        }




//        int hh=80;
//        while (hh<=100){
//            System.out.println(hh);
//            hh++;
//        }
//
//        int gg=40;
//        while (gg<=30){
//            System.out.println(gg);
//            gg++;
//        }



//        int b= 10;
//
//        while (b<=15){
//
//            System.out.println(b);
//            b++;
//        }


//        int c = 10;
//
//        do {
//            System.out.println(c);
//            c++;
//        }
//        while (c<=15);



//        int mm=90;
//        do{
//            System.out.println(mm);
//            mm++;
//        }
//        while (mm<=100);

//
//        int y =15;
//         while (y<=20){
//             System.out.println(y);
//             y++;
//         }
//
//
//         int x= 65;
//          while (x<=70){
//              System.out.println(x);
//              x++;
//          }
//
//
//          int u =40;
//          while (u<=50){
//              System.out.println(u);
//              u++;
//          }
//
//          int r=20;
//          while (r<=25){
//              System.out.println(r);
//              r++;
//          }
//
//
//        int d=10;
//
//        do{
//            System.out.println(d);
//            d++;
//        }
//        while (d<=15);
//
//
//        int t=30;
//        do{
//            System.out.println(t);
//            t++;
//        }
//        while (t<=40);
//
//        int s=90;
//        do{
//            System.out.println(s);
//            s++;
//        }
//        while(s<=100);
//
//
//        for (int i=10; i<=15; i=i+1){
//            System.out.println(i);
//        }
//
//


        for(int n=10;n<=15;n=n+1){
            if (n==13)
               // break;
                 continue;

            System.out.println(n);
        }


//        for (int b= 75;b<=80;b=b+1){
//            System.out.println(b);
//        }




        }




    }


