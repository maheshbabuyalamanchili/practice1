package Access_modifiers_protected1;

import Access_modifiers_protected.Class_1;

public class subclass extends Class_1 {

    public static void main(String[] args) {
        subclass C = new subclass();
        System.out.println(C.rollno);
        C.printrollno();
    }

    protected int rollno = 101;

    protected subclass(){
        rollno = 110;
    }

    protected void printrollno(){
        System.out.println(rollno);
    }

}

