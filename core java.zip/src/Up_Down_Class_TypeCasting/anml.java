package Up_Down_Class_TypeCasting;

class anml {
    int x =10;
    public void add(){
        System.out.println(x);
    }
}

