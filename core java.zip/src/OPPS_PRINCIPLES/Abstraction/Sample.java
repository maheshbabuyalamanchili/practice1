package OPPS_PRINCIPLES.Abstraction;

import Interface.Laptop;
import Interface.Lenovo;

public  abstract class  Sample  {
    public void copy() {
        System.out.println("lenovo copy code");

    }


    public void paste() {
        System.out.println("lenovo paste code");

    }

    public abstract void cut();

    public abstract void keyboard();


}







