package OPPS_PRINCIPLES.Abstraction;

public interface Laptop {
    public void copy();

    public void paste();

    public void cut();

    public void keyboard();


}


