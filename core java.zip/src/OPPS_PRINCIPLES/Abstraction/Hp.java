package OPPS_PRINCIPLES.Abstraction;

import Interface.Lenovo;

public class Hp extends Sample {



    public void cut() {
        System.out.println("cut code");

    }


    public void keyboard() {
        System.out.println("keyboard code");
    }
}
