package OPPS_PRINCIPLES.Abstraction;

public class Lenovo_1 extends Sample{

    public void cut() {
        System.out.println("cut code");

    }


    public void keyboard() {
        System.out.println("keyboard code");

    }
}
