package OPPS_PRINCIPLES.Abstraction;

public  abstract  class Lenovo implements Laptop   {



    public void copy() {
        System.out.println("lenovo copy code");

    }


    public void paste() {
        System.out.println("lenovo paste code");

    }

    public void cut(){

    }
     public void keyboard(){

 }


}
