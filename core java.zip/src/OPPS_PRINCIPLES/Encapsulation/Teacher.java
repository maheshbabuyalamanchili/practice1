package OPPS_PRINCIPLES.Encapsulation;

public class Teacher {
    public static void main(String[] args) {
        Student s = new Student(101);
        s.attendance=true;
    }
}
