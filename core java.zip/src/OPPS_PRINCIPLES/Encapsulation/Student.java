package OPPS_PRINCIPLES.Encapsulation;

public class Student {
    int rollno ;
    String name;
    boolean attendance;

    public Student(int rollno){
       this.rollno=rollno;
    }

}
