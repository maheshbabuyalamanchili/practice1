package OPPS_PRINCIPLES.Polymorphism;

public class Overriding {
    int a=20;
    int b=30;
    public void add(int a, int b){
        System.out.println(a+b);
        System.out.println("Existing fun");

    }
}
