package OPPS_PRINCIPLES.Inheritance;

class BB extends AA {
 int x= 30;
 int y=40;
 public void m2(){
     System.out.println("m2 excuted");
     System.out.println(a+b);


 }
}

