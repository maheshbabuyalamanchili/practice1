package OPPS_PRINCIPLES.Inheritance;

class AA {
    int a =10;
    int b = 20;
    public void m1(){
        System.out.println("m1 excuted");}
    }

