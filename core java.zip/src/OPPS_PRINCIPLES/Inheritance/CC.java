package OPPS_PRINCIPLES.Inheritance;

public class CC extends BB {
  public void m3(){
        System.out.println("m3 excuted");
        System.out.println(x+y);
        System.out.println(a+b);

    }

    public static void main(String[] args) {
        CC obj=new CC();
        obj.m1();
        obj.m2();
        obj.m3();
    }
}