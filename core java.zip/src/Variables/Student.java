package Variables;

public class Student {
    //Instance variable(non static field)static int id = 101;
 static int id = 20;

    public static void main(String[] args) {
        System.out.println(id);
        Student S=new Student();
        S.add();

        }
 public   void add(){
       id = 50;
     System.out.println(id);

    }

}
