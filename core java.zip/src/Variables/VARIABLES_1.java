package Variables;

//class variable(static field)
//public class Student1 {
//
//              static int id = 101;
//            static String name = "mahesh";
//
//              public static void main(String[] args) {
//                  System.out.println(id);
//                  System.out.println(name);
//
//              }
//          }


             //local variable


public class VARIABLES_1 {




              public static void main(String[] args) {
                  int height = 70;
                  test();

              }

              public  static void test(){
                 int height =70;
                  System.out.println(height);

              }
          }


                //parameters
//    public class Student3{
//
//    public static void main(String[] args) {
//        test(70);
//
//    }
//
//    public static void test(int height){
//        height=70;
//        System.out.println(height);
//
//    }
//}

















