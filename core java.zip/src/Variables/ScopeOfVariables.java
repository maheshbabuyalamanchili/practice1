package Variables;

public class ScopeOfVariables {

    static int a = 30;
    static int b;

    public static void main(String[] args) {
        b = 50;
        if (a < b) {
            int c;
            b = 80;
            c = b;
            System.out.println(c);
            System.out.println(a);
            System.out.println(b);


        }
    }
}