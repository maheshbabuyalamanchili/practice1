package Variables;

public class VARIABLES_2 {
    static int a=10;

   static int b=20;


    public static void main(String[] args) {
        int c=30;
        add();
        System.out.println(sub());
       VARIABLES_2 V= new VARIABLES_2();
        System.out.println(V.add1());
        System.out.println(V.sub1());





    }

    public static  void add(){
        int d=40;
        System.out.println(d+b);
    }
   public static int sub() {
       int a=10;
          return b-a;

    }


        public int add1(){
             int d=40;
             return d+b;

         }

   public int sub1() {
        return b-a;
    }

}