package Access_modifier_package_default;

class Class_1 {
    public static void main(String[] args) {

        Class_1 C = new Class_1();
        System.out.println(C.rollno);
        C.printrollno();
        C.abc();
    }

    int rollno=101;

    Class_1(){
        rollno=105;
    }
    void printrollno(){
        System.out.println(rollno);
    }
     public void abc(){
         System.out.println(rollno);
     }
}
